//常量区
var http = require("http");
var urlTool = require('url');
var querystring = require('querystring');
var pug = require("pug");
var fs = require('fs');
var validator = require('./js/validator');
var users = {};

//创建服务（过滤文件
http.createServer(function (req,res) {
    switch (req.url){
        case '/js/validator.js':
            sendFile(res,'js/validator.js','text/javascript');
            break;
        case '/js/signup.js':
            sendFile(res,'js/signup.js','text/javascript');
            break;
        case '/js/jquery.js':
            sendFile(res,'js/jquery.js','text/javascript');
            break;
        case '/css/style.css':
            sendFile(res,'css/style.css','text/css');
            break;
        case '/css/detail.css':
            sendFile(res,'css/detail.css','text/css');
            break;
        case '/image/background.jpg':
            sendFile(res,'image/background.jpg','image/jpeg');
            break;
        default:
            req.method === 'POST' ? registerUser(req,res) : sendHtml(req,res);
    }
}).listen(8000);

console.log("Signup server is listening at 8000");

//发送文件
function sendFile(res,filepath,mime) {
    res.writeHead(200,{"Content-Type":mime});
    res.end(fs.readFileSync(filepath));
}

//注册用户
function registerUser(req,res) {
    req.on('data',function (chunk) {
        try {
            var user = parseUser(chunk.toString());
            checkUser(user);
            users[user.username] = user;
            res.writeHead(301, {Location: '?username=' + user.username});
            res.end();
        }catch (e) {
            console.warn("register error:", e);
            showSignup(res,user,e.message);
        }
    });
}

//检查用户合法性（服务端
function checkUser(user) {
    var errorMessages = [];
    for(var key in user){
        if(!validator.isFieldValid(key,user[key])){
            errorMessages.push(validator.form[key].errorMessage);
        }
        if(!validator.isAttrValueUnique(users,user,key)){
            errorMessages.push(
                "key: "+key+" is not unique by value: " + user[key]
            );
        }
    }
    if(errorMessages.length > 0){
        throw new Error(errorMessages.join('<br />'));
    }
}

//分析用户信息
function parseUser(message) {
    //params = message.match(/usernam(.+)&sid=(.+)&phone=(.+)&email=(.+)/);
    //var user = {username:params[1],sid:params[2],phone:params[3],email:params[4]};
    var user = querystring.parse(message);
    console.log("user parsed is: ",user);
    return user;
}

//选择发送界面
function  sendHtml(req,res) {
    var username = parseUsername(req);
    if(!username||!isRegisterUser(username)){
        showSignup(res,{username:username},null);
    } else {
        showDetail(res,users[username]);
    }
}

//分析用户名
function parseUsername(req) {
    return querystring.parse(urlTool.parse(req.url).query).username;
}

//是否为已注册用户
function isRegisterUser(username) {
    return !!users[username];
}

//显示注册界面
function showSignup(res,user,error) {
    showhtml(res,'pug/sign',{user:user,error:error});
}

//显示详情界面
function showDetail(res,user) {
    showhtml(res,'pug/detail',user);
}

//显示html
function showhtml(res,template,data) {
    res.writeHead(200,{"Content-Type":"text/html"});
    res.end(pug.renderFile(template,data));
}