/*常量区*/
var isButtonCanClick = [false,false,false,false,false];
var isButtonActive = [false,false,false,false,false];
var isInfobarCanClick = false;
var numButtonActive = 0;
var url = "http://localhost:3000";
/*初始化*/
$(function () {
    $(".unread").hide();
    $(".unread").text(0);
    $("#button").mouseenter(function () {
        isButtonCanClick = [true,true,true,true,true];
    });
    $("#button").mouseleave(function () {
        $(".unread").hide();
        $(".unread").text(0);
        isButtonCanClick = [false,false,false,false,false];
        isButtonActive = [false,false,false,false,false];
        isInfobarCanClick = false;
        numButtonActive = 0;
        $("#sum").text("");
        $("#info-bar").css({
            "background-color": "#A9A9A9"
        });
        $(".button").css({
            "background-color": "#2F3BA2"
        })
    });
    $("#A").click(function () {
        buttonClick(0);
    });
    $("#B").click(function () {
        buttonClick(1)
    });
    $("#C").click(function () {
        buttonClick(2)
    });
    $("#D").click(function () {
        buttonClick(3)
    });
    $("#E").click(function () {
        buttonClick(4)
    });
    $("#info-bar").click(infoClick);
});

/*大气泡点击*/
function infoClick() {
    if(isInfobarCanClick){
        var sum = 0;
        for(var k = 0;k<5;k++){
            sum+= parseInt($(".unread").eq(k).text());
        }
        $("#sum").text(sum);
        isInfobarCanClick = false;
        $("#info-bar").css({
            "background-color": "#A9A9A9"
        });
    }
}

/*小按钮点击*/
function buttonClick(i){
    var p = new Promise(function (resolve,reject) {
        if(isButtonCanClick[i]){
            isButtonCanClick[i] = false;
            if(!isButtonActive[i]) {
                $(".unread").eq(i).show();
                isButtonActive[i] = true;
            }
            $(".unread").eq(i).text("...");
            setTimeout(function () {
                var j;
                for(j = 0;j<5;j++){
                    if(j!==i) {
                        if(isButtonCanClick[j]!==false) {
                            isButtonCanClick[j] = false;
                            $(".button").eq(j).css({
                                    "background-color": "#A9A9A9"
                                }
                            )
                        }
                    }
                }
                RunButton().then(function (value) {
                    $(".unread").eq(i).text(value);
                    numButtonActive++;
                    $(".button").eq(i).css({
                            "background-color": "#A9A9A9"
                        }
                    );
                    for(j = 0;j<5;j++){
                        if(j!==i) {
                            if(isButtonCanClick[j]!==true&&isButtonActive[j]===false) {
                                isButtonCanClick[j] = true;
                                $(".button").eq(j).css({
                                        "background-color": "#2F3BA2"
                                    }
                                );
                            }
                        }
                    }
                    if(numButtonActive===5){
                        isInfobarCanClick = true;
                        $("#info-bar").css({
                            "background-color": "#2F3BA2"
                        });
                    }
                    resolve("ok");
                });
            },0);

        }
    });
    return p;
}

/*按钮运行*/
function RunButton() {
    var p = new Promise(function (resolve, reject) {
        $.get(url,{name : Math.random()} , function (data) {
            resolve(data);
        });
    });
    return p;
}